# magly
this stands for magazine daily.
